<?php
class Db {
    public static $username = "root";
    public static $password = "mysql";
    public static $host = "localhost";
    public static $database = "forfaits";

}